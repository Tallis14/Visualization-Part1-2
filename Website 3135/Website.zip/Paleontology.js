$(document).ready(function() {
    $("#slider").bxSlider({
        moveSlides:1,
        speed:3000,
        auto: true,
        minSlides: 1,
        maxSlides: 1,
        slideWidth: 500,
        slideHeight: 500,
        height:500,
        slideMargin: 20,
        fill:true

    });
});